const gruen = document.getElementById("Gruen");
const gelb = document.getElementById("Gelb");
const rot = document.getElementById("Rot");

let n = 1
let setinterval;


function schalte(){
    if(n == 4){
        n = 1;
    }
    
    ampel(n)
    n++
   
}


function aus(){
    startAmpel(true)
    ampel()
    n= 1;
}



function ampel(n) {
    switch (n) {
        case 1:
            gruen.style.backgroundColor = "red";
            gelb.style.backgroundColor = "grey";
            rot.style.backgroundColor = "grey";
            break;
        case 2:
            gruen.style.backgroundColor = "red";
            gelb.style.backgroundColor = "yellow";
            rot.style.backgroundColor = "grey";
            break;
        case 3:
            gruen.style.backgroundColor = "grey";
            gelb.style.backgroundColor = "grey";
            rot.style.backgroundColor = "green";
            break;
        default:
            gruen.style.backgroundColor = "grey";
            gelb.style.backgroundColor = "grey";
            rot.style.backgroundColor = "grey";
    }
}



function startAmpel(aus = false){
    if(aus == true){
        clearInterval(setinterval);
        ampel()
         n= 1;
         return;
    } 
    setinterval = setInterval(schalte, 1000)
}

