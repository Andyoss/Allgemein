


let count = 0;
let n = 1;
let preis = 5;



function testalert()
{
    alert("Test btn has ben activatet")
};

const btn = document.getElementById("test1");

btn.addEventListener("click", function(){

klick()



})

function klick(){

    count += n
    console.log(count)
}


function doubleklicK(){
    if(count >= preis){
        n = n * 2
        preis = preis * 3
    }
    else{
        console.log("Es werden " + preis + " klicks benötigt!")
    }
}