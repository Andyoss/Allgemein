let guthaben = 0;









document.getElementById("mysub").onclick = function(){
   let eingabe = parseFloat(document.getElementById("guthaben").value);

    if(eingabe == "NaN")
    {
        return 0;
    }
    else
    {
        guthaben += eingabe;
        console.log(guthaben)
    }
}