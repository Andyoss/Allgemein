 // EventListener für den Button
 document.getElementById("eingabebtn").addEventListener("click", () => {
    const eingabe = document.getElementById("eingabe").value;
    fetchPokemon(eingabe);  
    console.log(eingabe)
    document.getElementById("suche").innerHTML = `<strong>Suche nach: <br> ${eingabe}</strong>`;

});

function displayPokemon(data) {
    const infoDiv = document.getElementById("daten");
    const types = data.types.map(typeInfo => typeInfo.type.name).join(", ");

    infoDiv.innerHTML = `
        <h3>${data.name}</h3>
        <p><strong>Höhe:</strong> ${data.height / 10} m</p>
        <p><strong>Gewicht:</strong> ${data.weight / 10} kg</p>
        <p><strong>Typen:</strong> ${types}</p>
        <h4>Fähigkeiten:</h4>
        <ul id="abilitiesList"></ul>
    `;

    // Hole das abilitiesList-Element
    const abilitiesList = document.getElementById("abilitiesList");

    // Schleife durch die Fähigkeiten
    data.abilities.forEach(element => {
        const abilityName = element.ability.name;
        abilitiesList.innerHTML += `<li>${abilityName}</li>`;
    });
}



async function fetchPokemon(pokemonName) {
    const url = `https://pokeapi.co/api/v2/pokemon/${pokemonName.toLowerCase()}`;
  
    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error("Pokémon nicht gefunden.");
    
        const data = await response.json();
        console.log(data);
        displayPokemon(data)

    } catch (error) {
        console.error("Fehler:", error);
    }

    
}
