



// Den Button, das Eingabefeld und das Ausgabe-Element auswählen
const berechnezeitButton = document.getElementById('berechneZeit');
const uhrzeitInput = document.getElementById("uhrzeit");
const neueUhrzeitOutput = document.getElementById("neueUhrzeit");

// Event-Listener für den Button hinzufügen
berechnezeitButton.addEventListener('click', function() {
    // Wert des Eingabefeldes für die Uhrzeit abrufen
    const uhrzeit = uhrzeitInput.value;

    // Button-ID übergeben
    klick(berechnezeitButton.id);

    if (uhrzeit) {
        // Funktion aufrufen, um 6 Stunden hinzuzufügen
        const neueZeit = gehzeitFreitag(uhrzeit);
        neueUhrzeitOutput.textContent = neueZeit; // Ausgabe der neuen Uhrzeit
    } else {
        alert("Gib eine gültige Uhrzeit ein.");
    }
});

// Funktion, um der eingegebenen Uhrzeit 6 Stunden hinzuzufügen
function gehzeitFreitag(zeit) {
    // Uhrzeit in Stunden und Minuten aufteilen
    let [stunden, minuten] = zeit.split(":").map(Number);

    // 6 Stunden hinzufügen
    stunden += 6;

    // Wenn die Stunden >= 24 sind, Tag zurücksetzen
    if (stunden >= 24) {
        stunden = stunden - 24;
    }

    // Stunden und Minuten zweistellig formatieren
    const stundenString = String(stunden).padStart(2, "0");
    const minutenString = String(minuten).padStart(2, "0");

    return `${stundenString}:${minutenString}`;
}

// Funktion zum Protokollieren der Button-ID
function klick(id) {
    console.log("Button mit ID: " + id + " wurde geklickt!");
}




document.getElementById("andereTests").addEventListener("click", () => {
    const eingabe = document.getElementById("eingabe").value;  
    console.log(eingabe)
    document.getElementById("suche").innerHTML = `<strong>Suche nach: <br> ${eingabe}</strong>`;

});



function andereTests(text)
{
    document.getElementById("andereTests").innerHTML = text
};






















function sort(arr) {
    let n = arr.length;
    for (let i = 0; i < n - 1; i++) {
        for (let j = 0; j < n - 1 - i; j++) {
            if (arr[j] > arr[j + 1]) {
                let temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
    return arr;
}

function random(anzahl, vonBis){
    let aw = [];
    vonBis += 1
    for(let i = 0; i < anzahl; i++){
        let a = Math.floor(Math.random() * vonBis);
        aw.push(a)
    }
    return (aw);
}



let b = random(50, 500)







console.log("Starte sortierung von " + b.length + " Elemente")
console.time("Bubble Sort Zeit");
console.log(sort(b))
console.timeEnd("Bubble Sort Zeit");
console.log("Benötiegte Zeit bei " + b.length + " Elemente")