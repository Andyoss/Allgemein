const kartenSpieler = document.getElementById('kartenSpieler');
const kartenDealer = document.getElementById('kartenDealer');
const spielerGesammt = document.getElementById('SpielerGesammt');
const dealerGesammt = document.getElementById('dealerGesammt');
const WinLoseAnzeige = document.getElementById('WinLoseAnzeige')
const btnActivateModal = document.getElementById('btnActivateModal');

const spielerWinAnzeige = document.getElementById('winsPlayer');
const dealerWinAnzeige = document.getElementById('winsDealer');

window.onload = function () {
    document.getElementById('btnActivateModal').onclick = modalActivate;
};


const originalDeck = [
    2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5,
    6, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8, 8, 9, 9, 9, 9,
    10, 10, 10, 10, 'Junge', 'Junge', 'Junge', 'Junge',
    'Queen', 'Queen', 'Queen', 'Queen', 'König', 'König', 'König', 'König',
    'Ass', 'Ass', 'Ass', 'Ass'
];
let karten = [...originalDeck];


let gamefinish = 0;
let showModal = 0;    // Modal Anzeigen 0 = aus 1 = ein

let spielerPunkte = 0;
let dealerPunkte = 0;

let spielerWins = 0;
let dealerWins = 0;

let alleKartenSpieler = [];
let alleKartenDealer = [];

init();
function init() {

    karten = [...originalDeck];
    alleKartenDealer = [];
    alleKartenSpieler = [];
    let zufallKarte = zufallsKarte()
    let punkte = berechnePunkte(zufallKarte, dealerPunkte);
    alleKartenDealer.push(zufallKarte)
    dealerPunkte += punkte;
    kartenDealer.innerHTML += `<li>${zufallKarte}</li>`;
    dealerGesammt.textContent = dealerPunkte;
    spielerWinAnzeige.textContent = spielerWins;
    dealerWinAnzeige.textContent = dealerWins;
}

function modalActivate() {
    if (showModal == 1) {
        showModal = 0
        btnActivateModal.style.backgroundColor = "red";

    }
    else {
        showModal = 1
        btnActivateModal.style.backgroundColor = "green";
    }
}

document.getElementById('karten').addEventListener('click', function () {
    if (gamefinish == 1) {
        gamefinish = 0;
        reset()
    }
    
    let zufallKarte = zufallsKarte()
    alleKartenSpieler.push(zufallKarte);
    let punkte = berechnePunkte(zufallKarte, spielerPunkte);
    spielerPunkte += punkte;
    
    spielerPunkte = pruefeAss(alleKartenSpieler, spielerPunkte);



    kartenSpieler.innerHTML += `<li>${zufallKarte}</li>`;
    spielerGesammt.textContent = spielerPunkte;

    if (spielerPunkte == 21){
        berechneDealer();
        ergebniss(spielerPunkte, dealerPunkte)
    }

    if (spielerPunkte > 21) {
        console.log(spielerPunkte)
        console.log("Über 21")
        
        showCustomAlert("Spieler Busted")
        wins(0)
    }
});

document.getElementById('hold').addEventListener('click', function () {
    if (gamefinish == 1) {
        gamefinish = 0;
        return reset()
    }
    else if (spielerPunkte == 0) {
        showCustomAlert("Spieler hat nicht gespielt")
        gamefinish = 1;
        return
    }
    berechneDealer();
    ergebniss(spielerPunkte, dealerPunkte)

});

function pruefeAss(karten, punkte) {
    console.log("Prüfe auf Ass")
    if (punkte > 21) {
        for (let i = 0; i < karten.length; i++) {
            if (karten[i] === 'Ass') {
                karten.splice(i, 1);
                console.log("Ass gefunden")
                return punkte -= 10;
            }
        }
    }
    return punkte;
}


function berechnePunkte(karte) {
    if (karte === 'Junge' || karte === 'Queen' || karte === 'König') {
        return 10;
    }
        else if(karte === 'Ass'){
            return 11
        }
    else {
        return karte;
    }
};

function zufallsKarte() {
    if (karten.length === 0) { alert("Deck ist Leer!") }

    let randomIndex = Math.floor(Math.random() * karten.length)
    let gezogeneKarte = karten.splice(randomIndex, 1)
    return gezogeneKarte[0]
}




function reset() {
    spielerPunkte = 0;
    dealerPunkte = 0;

    kartenSpieler.innerHTML = ``;
    spielerGesammt.textContent = spielerPunkte;

    kartenDealer.innerHTML = ``;
    dealerGesammt.textContent = dealerPunkte;

    init();
};





function berechneDealer() {
    while (dealerPunkte < 17) {  // Der Dealer zieht, bis er mindestens 17 hat
        let zufallKarte = zufallsKarte();  // Eine neue Karte ziehen

        alleKartenDealer.push(zufallKarte);
        let punkte = berechnePunkte(zufallKarte, dealerPunkte);
        dealerPunkte += punkte;
        
        dealerPunkte = pruefeAss(alleKartenDealer, dealerPunkte);
    
    
        // Karte im UI anzeigen
        kartenDealer.innerHTML += `<li>${zufallKarte}</li>`;
        dealerGesammt.textContent = dealerPunkte;  // Punkte aktualisieren

    }
}


function showCustomAlert(massage) {
    gamefinish = 1;
    if (showModal == 0) {

    }
    else {
        document.getElementById('customAlert').style.display = 'block';
        document.getElementById('modal').textContent = massage;
    }
}

function closeCustomAlert() {
    // Versteckt das benutzerdefinierte Alert-Fenster
    document.getElementById('customAlert').style.display = 'none';
}

function ergebniss(spieler, dealer) {

    if (spieler === 0) {
        showCustomAlert("Spieler hat nicht gespielt");
        console.log("ergebniss function")
        return; // Funktion beenden
    }
    if (spieler > 21) {
        showCustomAlert("Spieler Busted");
        wins(0)
    }
    if (dealer > 21) {
        showCustomAlert("Spieler gewinnt! Dealer Busted");
        wins(1)
        return; // Funktion beenden
    }
    if (spieler === 21) {
        showCustomAlert("Blackjack!");
        wins(1)
        return; // Funktion beenden
    }
    if (spieler === dealer) {
        showCustomAlert("Unentschieden, keiner gewinnt");
        return; // Funktion beenden
    }
    if (spieler > dealer) {
        showCustomAlert("Gewonnen");
        wins(1)
        return; // Funktion beenden
    }
    if (spieler < dealer) {
        showCustomAlert("Verloren");
        wins(0)
        return; // Funktion beenden
    }
}


function wins(wert) {
    if (wert == 0) {
        return dealerWins += 1;
    }
    else {
        return spielerWins += 1
    }
}


