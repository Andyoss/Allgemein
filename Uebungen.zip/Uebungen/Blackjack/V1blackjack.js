const kartenSpieler = document.getElementById('kartenSpieler');
const kartenDealer = document.getElementById('kartenDealer');
const spielerGesammt = document.getElementById('SpielerGesammt');
const dealerGesammt = document.getElementById('dealerGesammt');
const WinLoseAnzeige = document.getElementById('WinLoseAnzeige')
const btnActivateModal = document.getElementById('btnActivateModal');

const spielerWinAnzeige = document.getElementById('winsPlayer');
const dealerWinAnzeige = document.getElementById('winsDealer');

window.onload = function() {
    document.getElementById('btnActivateModal').onclick = modalActivate;
};


const karten = [2, 3, 4, 5, 6, 7, 8, 9, 10, 'Junge', 'Queen', 'König', 'Ass'];
let gamefinish = 0;
let showModal = 0;    // Modal Anzeigen 0 = aus 1 = ein

let spielerPunkte = 0;
let dealerPunkte = 0;

let spielerWins = 0;
let dealerWins = 0;



init();
function init() {
    let zufallKarte = zufallsKarte()
    let punkte = berechnePunkte(zufallKarte);
    dealerPunkte += punkte;
    kartenDealer.innerHTML += `<li>${zufallKarte}</li>`;
    dealerGesammt.textContent = dealerPunkte;
    spielerWinAnzeige.textContent = spielerWins;
    dealerWinAnzeige.textContent = dealerWins;
}

function modalActivate()
{
    if(showModal == 1)
    {
        showModal = 0
        btnActivateModal.style.backgroundColor = "red";

    }
    else 
    {
        showModal = 1
        btnActivateModal.style.backgroundColor = "green";
    }
}

document.getElementById('karten').addEventListener('click', function () {
    if(gamefinish == 1)
    {
        gamefinish = 0;
        reset()
    }
    let zufallKarte = zufallsKarte()
    let punkte = berechnePunkte(zufallKarte);
    spielerPunkte += punkte;
    kartenSpieler.innerHTML += `<li>${zufallKarte}</li>`;
    spielerGesammt.textContent = spielerPunkte;

    if (spielerPunkte > 21) {
        showCustomAlert("Spieler Busted")
        wins(0)
    }
});

document.getElementById('hold').addEventListener('click', function () {
    if(gamefinish == 1)
        {
            gamefinish = 0;
            return reset()
        }
    else if (spielerPunkte == 0) {
        showCustomAlert("Spieler hat nicht gespielt")
        console.log("ja gg")
        gamefinish = 1;
        return
    }
    berechneDealer();
    ergebniss(spielerPunkte, dealerPunkte)

});



function berechnePunkte(karte) {
    if (karte === 'Junge' || karte === 'Queen' || karte === 'König') {
        return 10;
    }
    else if (karte === 'Ass') {
        return 11;
    }
    else {
        return karte;
    }
};

function zufallsKarte() {
    let zufallKarte = karten[Math.floor(Math.random() * karten.length)];
    console.log(zufallKarte)
    return zufallKarte;
}



function reset() {
    spielerPunkte = 0;
    dealerPunkte = 0;

    kartenSpieler.innerHTML = ``;
    spielerGesammt.textContent = spielerPunkte;

    kartenDealer.innerHTML = ``;
    dealerGesammt.textContent = dealerPunkte;

    init();
};





function berechneDealer() {
    while (dealerPunkte < 17) {  // Der Dealer zieht, bis er mindestens 17 hat
        let zufallKarte = zufallsKarte();  // Eine neue Karte ziehen
        let punkte = berechnePunkte(zufallKarte);  // Punkte der Karte berechnen
        dealerPunkte += punkte;  // Punkte zur Gesamtsumme des Dealers hinzufügen

        // Karte im UI anzeigen
        kartenDealer.innerHTML += `<li>${zufallKarte}</li>`;
        dealerGesammt.textContent = dealerPunkte;  // Punkte aktualisieren

    }
}


function showCustomAlert(massage) {
    gamefinish = 1;
    if (showModal == 0) {

    }
    else {
        document.getElementById('customAlert').style.display = 'block';
        document.getElementById('modal').textContent = massage;
    }
}

function closeCustomAlert() {
    // Versteckt das benutzerdefinierte Alert-Fenster
    document.getElementById('customAlert').style.display = 'none';
}

function ergebniss(spieler, dealer) {

    if (spieler === 0) {
        showCustomAlert("Spieler hat nicht gespielt");
        console.log("ergebniss function")
        return; // Funktion beenden
    }
    if (spieler > 21) {
        showCustomAlert("Spieler Busted");
        wins(0)
    }
    if (dealer > 21) {
        showCustomAlert("Spieler gewinnt! Dealer Busted");
        wins(1)
        return; // Funktion beenden
    }
    if (spieler === 21) {
        showCustomAlert("Blackjack!");
        wins(1)
        return; // Funktion beenden
    }
    if (spieler === dealer) {
        showCustomAlert("Unentschieden, keiner gewinnt");
        return; // Funktion beenden
    }
    if (spieler > dealer) {
        showCustomAlert("Gewonnen");
        wins(1)
        return; // Funktion beenden
    }
    if (spieler < dealer) {
        showCustomAlert("Verloren");
        wins(0)
        return; // Funktion beenden
    }
}


function wins(wert) {
    if (wert == 0) {
        return dealerWins += 1;
    }
    else {
        return spielerWins += 1
    }
}


