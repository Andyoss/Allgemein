﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Einstiegspreis_Rechner
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnBerechnen_Click(object sender, EventArgs e)
        {
            int positionsgröße;
            double preisProAnteil;
            if (!int.TryParse(txtPositionsgröße.Text, out positionsgröße))
            {
                MessageBox.Show("Bitte eine gültige Zahl für die Positionsgröße eingeben!");
                return;
            }

            if (!double.TryParse(txtPreisProAnteil.Text, out preisProAnteil))
            {
                MessageBox.Show("Bitte einen gültigen Betrag für den Preis pro Anteil eingeben!");
                return;
            }

            double gesamtkosten = positionsgröße * preisProAnteil;

            MessageBox.Show($"Die Gesamtkosten betragen: {gesamtkosten:F2} €");

        }
    }
}
