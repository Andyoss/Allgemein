﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // Eingabe der aktuellen Position
        Console.WriteLine("Gib den aktuellen Betrag (USDT) ein:");
        double currentInvestment = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Gib den aktuellen Einstiegspreis ein:");
        double currentEntryPrice = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Gib den gewünschten Einstiegspreis ein:");
        double desiredEntryPrice = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Gib den aktuellen Marktpreis ein:");
        double marketPrice = Convert.ToDouble(Console.ReadLine());

        // Berechnung der aktuellen Anteile
        double currentShares = currentInvestment / currentEntryPrice;

        // Formel zur Berechnung des Nachkaufbetrags
        double numerator = (currentShares * desiredEntryPrice) - (currentShares * currentEntryPrice);
        double denominator = marketPrice - desiredEntryPrice;

        if (denominator <= 0)
        {
            Console.WriteLine("Nachkauf ist nicht möglich, da der Marktpreis kleiner oder gleich dem gewünschten Einstiegspreis ist.");
        }
        else
        {
            double additionalShares = numerator / denominator;
            double additionalInvestment = additionalShares * marketPrice;

            // Ausgabe der Ergebnisse
            Console.WriteLine($"Du musst {additionalShares:F4} Anteile zu {marketPrice} USDT kaufen.");
            Console.WriteLine($"Das bedeutet eine zusätzliche Investition von {additionalInvestment:F2} USDT.");
        }

        Console.WriteLine("Drücke eine beliebige Taste, um das Programm zu beenden.");
        Console.ReadKey();
    }
}
