﻿



Console.WriteLine("Netto Für ein Jahr oder ein Monat berechnen (j/m))?");
string? jOrm = Console.ReadLine();

Console.WriteLine("Gibt den Bruttobetrag ein: ");
double brutto = Convert.ToDouble(Console.ReadLine());

Console.WriteLine("Der Nettobetrag beläuft sich auf: " + NettoBerechnen(brutto));



//hier methode zum berechen des Nettos erstellen


static double NettoBerechnen(double brutto)
{
    double netto = 0;
    float Lohnsteuer = 27.5F;
    float Sozialversicherung = 13;

    netto = brutto - ((brutto / 100) * Sozialversicherung);
    netto = netto - ((netto / 100) * Lohnsteuer);

    return netto;
};