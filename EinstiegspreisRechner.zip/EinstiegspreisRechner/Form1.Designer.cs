﻿namespace EinstiegspreisRechner
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            contextMenuStrip1 = new ContextMenuStrip(components);
            dataGridViewPosition = new DataGridView();
            Positionsgroesse = new DataGridViewTextBoxColumn();
            PreisProCoin = new DataGridViewTextBoxColumn();
            lblEinsteigspreis = new Label();
            BtnBerechnen = new Button();
            BtnNeu = new Button();
            BtnDelete = new Button();
            AnteileGesamt = new Label();
            PositinGesamt = new Label();
            label3 = new Label();
            label4 = new Label();
            label1 = new Label();
            tableLayoutPanel1 = new TableLayoutPanel();
            numericPreisPerCoin = new NumericUpDown();
            label2 = new Label();
            lblNachkaufmenge = new Label();
            label5 = new Label();
            label6 = new Label();
            numericGewuenschterEinstieg = new NumericUpDown();
            btnBerechneEinstieg = new Button();
            btnNachkaufEinfuegen = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewPosition).BeginInit();
            tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericPreisPerCoin).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericGewuenschterEinstieg).BeginInit();
            SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(61, 4);
            // 
            // dataGridViewPosition
            // 
            dataGridViewPosition.AllowDrop = true;
            dataGridViewPosition.AllowUserToOrderColumns = true;
            dataGridViewPosition.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewPosition.Columns.AddRange(new DataGridViewColumn[] { Positionsgroesse, PreisProCoin });
            dataGridViewPosition.Location = new Point(12, 12);
            dataGridViewPosition.MinimumSize = new Size(300, 100);
            dataGridViewPosition.Name = "dataGridViewPosition";
            dataGridViewPosition.Size = new Size(360, 150);
            dataGridViewPosition.TabIndex = 0;
            dataGridViewPosition.CellValidating += dataGridViewPosition_CellValidating;
            // 
            // Positionsgroesse
            // 
            Positionsgroesse.HeaderText = "Positionsgröße";
            Positionsgroesse.Name = "Positionsgroesse";
            Positionsgroesse.Width = 150;
            // 
            // PreisProCoin
            // 
            PreisProCoin.HeaderText = "Preis/pro coin";
            PreisProCoin.Name = "PreisProCoin";
            PreisProCoin.Width = 150;
            // 
            // lblEinsteigspreis
            // 
            lblEinsteigspreis.AutoSize = true;
            lblEinsteigspreis.Location = new Point(205, 220);
            lblEinsteigspreis.Name = "lblEinsteigspreis";
            lblEinsteigspreis.Size = new Size(19, 21);
            lblEinsteigspreis.TabIndex = 9;
            lblEinsteigspreis.Text = "0";
            // 
            // BtnBerechnen
            // 
            BtnBerechnen.Dock = DockStyle.Fill;
            BtnBerechnen.Location = new Point(3, 3);
            BtnBerechnen.Name = "BtnBerechnen";
            BtnBerechnen.Size = new Size(114, 43);
            BtnBerechnen.TabIndex = 101;
            BtnBerechnen.Text = "Berechnen";
            BtnBerechnen.UseVisualStyleBackColor = true;
            BtnBerechnen.Click += BtnBerechnen_Click;
            // 
            // BtnNeu
            // 
            BtnNeu.Dock = DockStyle.Fill;
            BtnNeu.Location = new Point(123, 3);
            BtnNeu.Name = "BtnNeu";
            BtnNeu.Size = new Size(114, 43);
            BtnNeu.TabIndex = 102;
            BtnNeu.Text = "Neu";
            BtnNeu.UseVisualStyleBackColor = true;
            BtnNeu.Click += BtnNeu_Click;
            // 
            // BtnDelete
            // 
            BtnDelete.Dock = DockStyle.Fill;
            BtnDelete.Location = new Point(243, 3);
            BtnDelete.Name = "BtnDelete";
            BtnDelete.Size = new Size(114, 43);
            BtnDelete.TabIndex = 103;
            BtnDelete.Text = "Löschen";
            BtnDelete.UseVisualStyleBackColor = true;
            BtnDelete.Click += BtnDelete_Click;
            // 
            // AnteileGesamt
            // 
            AnteileGesamt.AutoSize = true;
            AnteileGesamt.Location = new Point(205, 262);
            AnteileGesamt.Name = "AnteileGesamt";
            AnteileGesamt.Size = new Size(19, 21);
            AnteileGesamt.TabIndex = 15;
            AnteileGesamt.Text = "0";
            // 
            // PositinGesamt
            // 
            PositinGesamt.AutoSize = true;
            PositinGesamt.Location = new Point(205, 241);
            PositinGesamt.Name = "PositinGesamt";
            PositinGesamt.Size = new Size(19, 21);
            PositinGesamt.TabIndex = 16;
            PositinGesamt.Text = "0";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 262);
            label3.Name = "label3";
            label3.Size = new Size(118, 21);
            label3.TabIndex = 17;
            label3.Text = "Anteile Gesamt:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 241);
            label4.Name = "label4";
            label4.Size = new Size(173, 21);
            label4.TabIndex = 18;
            label4.Text = "Positionsgröße Gesamt:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 220);
            label1.Name = "label1";
            label1.Size = new Size(108, 21);
            label1.TabIndex = 19;
            label1.Text = "Einstiegspreis:";
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 3;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.Controls.Add(BtnBerechnen, 0, 0);
            tableLayoutPanel1.Controls.Add(BtnNeu, 1, 0);
            tableLayoutPanel1.Controls.Add(BtnDelete, 2, 0);
            tableLayoutPanel1.Location = new Point(12, 168);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.Size = new Size(360, 49);
            tableLayoutPanel1.TabIndex = 20;
            // 
            // numericPreisPerCoin
            // 
            numericPreisPerCoin.Location = new Point(205, 349);
            numericPreisPerCoin.Maximum = new decimal(new int[] { 9999999, 0, 0, 0 });
            numericPreisPerCoin.Name = "numericPreisPerCoin";
            numericPreisPerCoin.Size = new Size(100, 29);
            numericPreisPerCoin.TabIndex = 105;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 351);
            label2.Name = "label2";
            label2.Size = new Size(110, 21);
            label2.TabIndex = 22;
            label2.Text = "Preis/pro coin:";
            // 
            // lblNachkaufmenge
            // 
            lblNachkaufmenge.AutoSize = true;
            lblNachkaufmenge.Location = new Point(205, 394);
            lblNachkaufmenge.Name = "lblNachkaufmenge";
            lblNachkaufmenge.Size = new Size(19, 21);
            lblNachkaufmenge.TabIndex = 23;
            lblNachkaufmenge.Text = "0";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(15, 394);
            label5.Name = "label5";
            label5.Size = new Size(127, 21);
            label5.TabIndex = 24;
            label5.Text = "Nachkaufmenge:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(12, 316);
            label6.Name = "label6";
            label6.Size = new Size(162, 21);
            label6.TabIndex = 26;
            label6.Text = "Gewünschter Einstieg:";
            // 
            // numericGewuenschterEinstieg
            // 
            numericGewuenschterEinstieg.Location = new Point(205, 314);
            numericGewuenschterEinstieg.Maximum = new decimal(new int[] { 9999999, 0, 0, 0 });
            numericGewuenschterEinstieg.Name = "numericGewuenschterEinstieg";
            numericGewuenschterEinstieg.Size = new Size(100, 29);
            numericGewuenschterEinstieg.TabIndex = 104;
            // 
            // btnBerechneEinstieg
            // 
            btnBerechneEinstieg.Location = new Point(15, 428);
            btnBerechneEinstieg.Name = "btnBerechneEinstieg";
            btnBerechneEinstieg.Size = new Size(159, 30);
            btnBerechneEinstieg.TabIndex = 106;
            btnBerechneEinstieg.Text = "Berechne Einstieg";
            btnBerechneEinstieg.UseVisualStyleBackColor = true;
            btnBerechneEinstieg.Click += btnBerechneEinstieg_Click;
            // 
            // btnNachkaufEinfuegen
            // 
            btnNachkaufEinfuegen.Location = new Point(15, 464);
            btnNachkaufEinfuegen.Name = "btnNachkaufEinfuegen";
            btnNachkaufEinfuegen.Size = new Size(159, 30);
            btnNachkaufEinfuegen.TabIndex = 107;
            btnNachkaufEinfuegen.Text = "Nachkauf Einfügen";
            btnNachkaufEinfuegen.UseVisualStyleBackColor = true;
            btnNachkaufEinfuegen.Click += btnNachkaufEinfuegen_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(9F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(384, 511);
            Controls.Add(btnNachkaufEinfuegen);
            Controls.Add(label6);
            Controls.Add(numericGewuenschterEinstieg);
            Controls.Add(btnBerechneEinstieg);
            Controls.Add(label5);
            Controls.Add(lblNachkaufmenge);
            Controls.Add(label2);
            Controls.Add(numericPreisPerCoin);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(label1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(PositinGesamt);
            Controls.Add(AnteileGesamt);
            Controls.Add(lblEinsteigspreis);
            Controls.Add(dataGridViewPosition);
            Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(4);
            MinimumSize = new Size(400, 550);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Einstiegspreis Rechner";
            FormClosed += Form1_FormClosed;
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewPosition).EndInit();
            tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)numericPreisPerCoin).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericGewuenschterEinstieg).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private ContextMenuStrip contextMenuStrip1;
        private DataGridView dataGridViewPosition;
        private Label lblEinsteigspreis;
        private Button BtnBerechnen;
        private Button BtnNeu;
        private Button BtnDelete;
        private Label AnteileGesamt;
        private Label PositinGesamt;
        private Label label3;
        private Label label4;
        private Label label1;
        private TableLayoutPanel tableLayoutPanel1;
        private NumericUpDown numericPreisPerCoin;
        private Label label2;
        private Label lblNachkaufmenge;
        private Label label5;
        private Label label6;
        private NumericUpDown numericGewuenschterEinstieg;
        private Button btnBerechneEinstieg;
        private DataGridViewTextBoxColumn Positionsgroesse;
        private DataGridViewTextBoxColumn PreisProCoin;
        private Button btnNachkaufEinfuegen;
    }
}
