﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EinstiegspreisRechner
{
    internal class Rechner
    {



        //empfohlen, keine Sonderzeichen wie "ß" in Bezeichnern (Variablen- oder Spaltennamen) zu verwenden
        public static decimal Gesamtkosten(DataGridView dataGridView)
        {
            decimal gesamtkosten = 0;
            
            foreach (DataGridViewRow row in dataGridView.Rows)
            {
                
                if (row.Cells["PreisProCoin"].Value != null && row.Cells["PreisProCoin"].Value != "" && 
                    row.Cells["Positionsgroesse"].Value != null && row.Cells["Positionsgroesse"].Value != "")
                {
                    if (decimal.TryParse(row.Cells["Positionsgroesse"].Value.ToString(), out decimal price))
                    {
                        gesamtkosten += price;
                    }
                }
            }

            return gesamtkosten;
        }




        public static decimal GesamtanzahlCoins(DataGridView dataGridView)
        {
            decimal anzahlCoins = 0;

            foreach (DataGridViewRow row in dataGridView.Rows)
            {
                if (row.Cells["PreisProCoin"].Value != null && row.Cells["Positionsgroesse"].Value != null)
                {
                    // Preis und Positionsgröße sicher parsen
                    if (decimal.TryParse(row.Cells["PreisProCoin"].Value.ToString(), out decimal preisProCoin) &&
                        decimal.TryParse(row.Cells["Positionsgroesse"].Value.ToString(), out decimal positionsgroesse))
                    {
                        // Berechnung der Anzahl Coins: Positionsgröße / Preis pro Coin
                        if (positionsgroesse == 0 || preisProCoin == 0)
                        {
                            return 0;
                        }
                        anzahlCoins += positionsgroesse / preisProCoin;
                    }
                }
            }

            return anzahlCoins;
        }













        public static decimal BerechneEinstiegspreis(DataGridView dataGridView)
        {
            decimal totalSum = 0;
            decimal totalPosition = 0;

            foreach (DataGridViewRow row in dataGridView.Rows)
            {
                if (row.Cells["Positionsgroesse"].Value != null && row.Cells["PreisProCoin"].Value != null)
                {
                    if (decimal.TryParse(row.Cells["Positionsgroesse"].Value.ToString(), out decimal positionsgroesse) &&
                        decimal.TryParse(row.Cells["PreisProCoin"].Value.ToString(), out decimal preisProCoin))
                    {
                        totalSum += positionsgroesse * preisProCoin;
                        totalPosition += positionsgroesse;
                    }
                }
            }

            if (totalPosition > 0)
            {
                decimal einstiegspreis = totalSum / totalPosition;
                return Math.Round(einstiegspreis, 5);  // Rundung auf 5 Nachkommastellen
            }

            return 0;
        }



        public static int BerechneNachkaufMenge(DataGridView dataGridView, decimal neuerKaufpreis, decimal gewunschterEinstieg)
        {
            if (neuerKaufpreis == 0 && gewunschterEinstieg == 0)
            {

                return 0;
            }
            if (gewunschterEinstieg < neuerKaufpreis)
            {
                MessageBox.Show("Einstieg kann nicht kleiner als Coinwert sein.");
                return 0;
            }
            if (gewunschterEinstieg == neuerKaufpreis)
            {
                MessageBox.Show("Einstieg und Coinwert dürfen nicht gleich sein.");
                return 0;
            }

            decimal totalSum = 0;
            decimal totalPosition = 0;


            foreach (DataGridViewRow row in dataGridView.Rows)
            {
                if (row.Cells["Positionsgroesse"].Value != null && row.Cells["PreisProCoin"].Value != null)
                {
                    if (decimal.TryParse(row.Cells["Positionsgroesse"].Value.ToString(), out decimal positionsgroesse) &&
                        decimal.TryParse(row.Cells["PreisProCoin"].Value.ToString(), out decimal preisProCoin))
                    {
                        if(positionsgroesse != 0 && preisProCoin != 0)
                        { 
                        totalSum += positionsgroesse * preisProCoin;
                        totalPosition += positionsgroesse;
                        }
                    }
                }
            }

            if (totalPosition == 0)
            {
                MessageBox.Show("Gib oben einen Position ein.");
                return 0;
            }

            decimal aktuellerEP = totalSum / totalPosition;



            decimal benoetigteMenge = (gewunschterEinstieg * totalPosition - aktuellerEP * totalPosition) / (neuerKaufpreis - gewunschterEinstieg);

            return (int)Math.Ceiling(benoetigteMenge);
        }


        private static bool eingabeisnotnull(decimal wert)
        {

            if(wert == null || wert == 0)
            {
                return false;
            }
            
            
            
            
            return true;
        }



    }
}
