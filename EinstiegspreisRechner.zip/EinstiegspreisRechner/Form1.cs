using System.Windows.Forms;

namespace EinstiegspreisRechner
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string safePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "EinstiegspreisRechner_Data.csv");

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridViewPosition.AllowUserToAddRows = false;
            dataGridViewPosition.AllowUserToDeleteRows = false;
            dataGridViewPosition.ReadOnly = false;
            dataGridViewPosition.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridViewPosition.MultiSelect = false;
            dataGridViewPosition.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewPosition.RowHeadersVisible = false;
            dataGridViewPosition.EditMode = DataGridViewEditMode.EditOnEnter;
            dataGridViewPosition.ColumnHeadersVisible = true;
            dataGridViewPosition.BorderStyle = BorderStyle.FixedSingle;
            dataGridViewPosition.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;
            dataGridViewPosition.Font = new Font("Arial", 10, FontStyle.Regular);

            LoadDataFromFile(safePath);

            //F�hrt den Btn wie eine Metohde aus is ganz nice
            BtnBerechnen_Click(null, EventArgs.Empty);

            btnBerechneEinstieg_Click(null, EventArgs.Empty);

        }

        private void AddHardcodedEntries()
        {
            // Spalten hinzuf�gen, falls sie noch nicht existieren
            if (dataGridViewPosition.Columns.Count == 0)
            {
                dataGridViewPosition.Columns.Add("PreisProCcoin", "Preis pro Coin");
                dataGridViewPosition.Columns.Add("Positionsgroesse", "Positionsgr��e");
            }

            // Hardcodierte Eintr�ge hinzuf�gen
            dataGridViewPosition.Rows.Add("100", "100");  // 1. Eintrag: Preis 50.000, Positionsgr��e 2
            dataGridViewPosition.Rows.Add("100", "50"); // 2. Eintrag: Preis 45.000, Positionsgr��e 1.5
        }



        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridViewPosition.SelectedRows.Count > 0)
            {
                dataGridViewPosition.Rows.RemoveAt(dataGridViewPosition.SelectedRows[0].Index);
            }
        }

        private void BtnNeu_Click(object sender, EventArgs e)
        {
            // Neue Zeile hinzuf�gen
            dataGridViewPosition.Rows.Add("", "");

            // Index der letzten Zeile ermitteln
            int lastRowIndex = dataGridViewPosition.Rows.Count - 1;

            dataGridViewPosition.ClearSelection();
            // Letzte Zeile ausw�hlen
            dataGridViewPosition.CurrentCell = dataGridViewPosition.Rows[lastRowIndex].Cells[0];

            // Sicherstellen, dass die Zeile ausgew�hlt ist
            dataGridViewPosition.Rows[lastRowIndex].Selected = true;

            // In Bearbeitungsmodus wechseln, um das Schreiben zu erm�glichen
            dataGridViewPosition.BeginEdit(true);
        }



        private void dataGridViewPosition_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (dataGridViewPosition.Columns[e.ColumnIndex].Name == "Positionsgroesse" || dataGridViewPosition.Columns[e.ColumnIndex].Name == "PreisProCoin")
            {
                if (!decimal.TryParse(e.FormattedValue.ToString(), out _))
                {
                    MessageBox.Show("Bitte eine g�ltige Zahl eingeben!");
                    e.Cancel = true;
                }
            }
        }

        private void BtnBerechnen_Click(object sender, EventArgs e)
        {
            lblEinsteigspreis.Text = Rechner.BerechneEinstiegspreis(dataGridViewPosition).ToString();



            PositinGesamt.Text = Rechner.Gesamtkosten(dataGridViewPosition).ToString("N3");

            AnteileGesamt.Text = Rechner.GesamtanzahlCoins(dataGridViewPosition).ToString("N3");


            btnBerechneEinstieg_Click(null, EventArgs.Empty);

        }



        private void SaveDataToCSV(string filePath)
        {

                using (StreamWriter writer = new StreamWriter(filePath))
                {
                // Header schreiben

                    writer.WriteLine("Positionsgr��e,PreisProCoin");

                // Daten aus DataGridView speichern
                foreach (DataGridViewRow row in dataGridViewPosition.Rows)
                    {
                        if (row.Cells[0].Value != null && row.Cells[1].Value != null)
                        {
                            writer.WriteLine($"{row.Cells[0].Value},{row.Cells[1].Value}");
                        }
                    }

                // Zus�tzliche Daten speichern

                writer.WriteLine("GewuenschterEinstieg,PreisPerCoin");

                writer.WriteLine($"{numericGewuenschterEinstieg.Value},{numericPreisPerCoin.Value}");
                }
            }




        private void LoadDataFromFile(string filePath)
        {
            try
            {
                if (!File.Exists(filePath))
                {
                    MessageBox.Show("Die Datei existiert nicht!", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string[] lines = File.ReadAllLines(filePath);
                dataGridViewPosition.Rows.Clear();

                bool isDataSection = false;
                bool isNumericSection = false;

                foreach (string line in lines)
                {
                    string trimmedLine = line.Trim();

                    if (trimmedLine == "Positionsgr��e,PreisProCoin")
                    {
                        isDataSection = true;
                        isNumericSection = false;
                        continue;
                    }

                    if (trimmedLine == "GewuenschterEinstieg,PreisPerCoin")
                    {
                        isDataSection = false;
                        isNumericSection = true;
                        continue;
                    }

                    // Daten aus der Tabelle hinzuf�gen
                    if (isDataSection)
                    {
                        string[] values = trimmedLine.Split(',');
                        if (values.Length == 2)
                        {
                            dataGridViewPosition.Rows.Add(values[0].Trim(), values[1].Trim());
                        }
                    }
                    // Numerische Werte einlesen
                    else if (isNumericSection)
                    {
                        string[] values = trimmedLine.Split(',');
                        if (values.Length == 2)
                        {
                            if (decimal.TryParse(values[0].Trim(), out decimal gewEinstieg))
                            {
                                numericGewuenschterEinstieg.Value = gewEinstieg;
                            }
                            else
                            {
                                MessageBox.Show("Ung�ltiger Wert f�r Gew�nschter Einstieg.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }

                            if (decimal.TryParse(values[1].Trim(), out decimal preisPerCoin))
                            {
                                numericPreisPerCoin.Value = preisPerCoin;
                            }
                            else
                            {
                                MessageBox.Show("Ung�ltiger Wert f�r Preis per Coin.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }

             
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Fehler beim Laden der Daten: {ex.Message}", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }




        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            SaveDataToCSV(safePath);
        }

        private void btnBerechneEinstieg_Click(object sender, EventArgs e)
        {
            decimal neuerKaufpreis = numericPreisPerCoin.Value;
            decimal gewunschterEinstieg = numericGewuenschterEinstieg.Value;



            lblNachkaufmenge.Text = Rechner.BerechneNachkaufMenge(dataGridViewPosition, neuerKaufpreis, gewunschterEinstieg).ToString();
        }
    }
}

